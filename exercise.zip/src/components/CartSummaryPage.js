import React from 'react';
import { useCart } from './CartContext';
import './CartSummaryPage.css';
import logo from '../assets/tom.jpeg'; // Import your logo image here

const CartSummaryPage = () => {
  const { getTotalQuantity, getTotalAmount } = useCart();

  return (
    <div className="cart-summary-page">
      <h2 className="summary-title">Cart Summary</h2>
      <div className="summary-details">
        <p className="summary-item">
          <span>Total Quantity:</span>
          <span className="summary-value">{getTotalQuantity()}</span>
        </p>
        <p className="summary-item">
          <span>Total Amount:</span>
          <span className="summary-value">${getTotalAmount()}</span>
        </p>
      </div>
      <div className="thank-you">
        <p>Thank you for shopping with us!</p>
      </div>
      <img src={logo} alt="Logo" className="cart-summary-image" />
    </div>
  );
};

export default CartSummaryPage;
