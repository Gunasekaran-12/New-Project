import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Inventory from './components/Inventory';
import './App.css'; // Import global styles

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Login />} /> {/* Redirect root to Login */}
      <Route path="/login" element={<Login />} />
      <Route path="/inventory" element={<Inventory />} />
      <Route path="*" element={<div>404 Not Found</div>} /> {/* Fallback route */}
    </Routes>
  </Router>
);

export default App;
