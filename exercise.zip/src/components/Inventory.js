import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from './CartContext';
import './Inventory.css'; 
import logo from '../assets/G logo.png';
/*import logo2 from '../assets/G logo2.png';*/
const Inventory = () => {
  const { cart, addToCart } = useCart();
  const navigate = useNavigate();

  const medicines = [
    { id: 1, name: 'Aspirin', rate: 10, image: "https://m.media-amazon.com/images/I/518EiFnQNwL._SY466_.jpg" },
    { id: 2, name: 'Amoxicillin', rate: 15, image: "https://m.media-amazon.com/images/I/71urZ0OmQvL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 3, name: 'Ibuprofen', rate: 20, image: "https://m.media-amazon.com/images/I/81pXdWfPkrL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 4, name: 'Paracetamol', rate: 5, image: "https://m.media-amazon.com/images/I/81JbkDm0UjL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 5, name: 'Lisinopril', rate: 25, image: "https://m.media-amazon.com/images/I/81HOeJgsz3L._AC_UL480_FMwebp_QL65_.jpg" }, 
    { id: 6, name: 'Metformin', rate: 30, image: "https://m.media-amazon.com/images/I/517H+SIFoOL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 7, name: 'Omeprazole', rate: 18, image: "https://m.media-amazon.com/images/I/71St717fsuL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 8, name: 'Simvastatin', rate: 22, image: "https://m.media-amazon.com/images/I/51U97QUX1UL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 9, name: 'metformin', rate: 12, image: "https://m.media-amazon.com/images/I/517H+SIFoOL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 10, name: 'Atorvastatin', rate: 20, image: "https://m.media-amazon.com/images/I/41l-4AFIUtL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 11, name: 'Citalopram', rate: 15, image: "https://m.media-amazon.com/images/I/615hdH2e1pL._SX522_.jpg" },
    { id: 12, name: 'Clopidogrel', rate: 18, image: "https://m.media-amazon.com/images/I/91zZVqvo1cL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 13, name: 'Doxycycline', rate: 25, image: "https://m.media-amazon.com/images/I/615Izgo3cEL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 14, name: 'Fluoxetine', rate: 22, image: "https://m.media-amazon.com/images/I/61hTebnFdRL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 15, name: 'Gabapentin', rate: 10, image: "https://m.media-amazon.com/images/I/81CUUq3WsqL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 16, name: 'Levothyroxine', rate: 20, image: "https://m.media-amazon.com/images/I/619sznFR0gL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 17, name: 'Losartan', rate: 18, image: "https://m.media-amazon.com/images/I/61O0x2KSmmL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 18, name: 'Metoprolol', rate: 15, image: "https://m.media-amazon.com/images/I/81rRLq1FUjL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 19, name: 'Naproxen', rate: 12, image: "https://m.media-amazon.com/images/I/71Ttw4swa5L._AC_UL960_FMwebp_QL65_.jpg" },
    { id: 20, name: 'Pantoprazole', rate: 8, image: "https://m.media-amazon.com/images/I/718gWSSsvHL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 21, name: 'Prednisone', rate: 18, image: "https://m.media-amazon.com/images/I/51d7FXw-8dL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 22, name: 'Ranitidine', rate: 10, image: "https://m.media-amazon.com/images/I/61pYFrUbYfL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 23, name: 'Tamsulosin', rate: 15, image: "https://m.media-amazon.com/images/I/81vbNGrUM9L._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 24, name: 'Warfarin', rate: 20, image: "https://m.media-amazon.com/images/I/51HdCKGR0eL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 25, name: 'Zolpidem', rate: 25, image: "https://m.media-amazon.com/images/I/61skiHKMnXL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 26, name: 'Azithromycin', rate: 20, image: "https://m.media-amazon.com/images/I/61woa4saNZL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 27, name: 'Benzonatate', rate: 12, image: "https://m.media-amazon.com/images/I/61Lik00tIyL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 28, name: 'Cefalexin', rate: 15, image: "https://m.media-amazon.com/images/I/71fYk-McJwL._AC_UL480_FMwebp_QL65_.jpg" },
    { id: 29, name: 'Diazepam', rate: 22, image: "https://m.media-amazon.com/images/I/71A6j1-kWTL._AC_UY327_FMwebp_QL65_.jpg" },
    { id: 30, name: 'Esomeprazole', rate: 18, image: "https://m.media-amazon.com/images/I/61MTtXqPCyL._AC_UL480_FMwebp_QL65_.jpg" }
  ];

  const [quantities, setQuantities] = useState(
    medicines.reduce((acc, med) => {
      acc[med.id] = 0;
      return acc;
    }, {})
  );

  const handleIncreaseQuantity = (id) => {
    setQuantities(prev => ({
      ...prev,
      [id]: prev[id] + 1
    }));
  };

  const handleDecreaseQuantity = (id) => {
    setQuantities(prev => ({
      ...prev,
      [id]: prev[id] > 0 ? prev[id] - 1 : 0
    }));
  };

  const handleAddToCart = (medicine) => {
    if (quantities[medicine.id] > 0) {
      addToCart({ ...medicine, quantity: quantities[medicine.id] });
    } else {
      alert('Please select a quantity before adding to the cart');
    }
  };

  const handleGoToCart = () => {
    navigate('/cart-summary'); // Redirect to Cart Summary page
  };

  return (
    <div className="inventory-container">
      <div className="head">
        <img className="img" src={logo} alt=''/>
        Health
          </div>
      <div className="nav-links">
        <Link to="/inventory" className="nav-link1">Home</Link>
        <Link to="/about-us" className="nav-link2">About Us</Link>
        <Link to="/contact-us" className="nav-link3">Contact Us</Link>
        <Link to="/login" className="nav-link4">Sign Up</Link>
      </div>
      <div className="carts-section">
        <div className="carts-grid">
          {medicines.map(med => (
            <div key={med.id} className="cart">
              <img src={med.image} alt={med.name} />
              <h3>{med.name}</h3>
              <p>Rate: ${med.rate}</p>
              <div className="quantity-controls">
                <button onClick={() => handleDecreaseQuantity(med.id)} className="quantity-button">-</button>
                <span>{quantities[med.id]}</span>
                <button onClick={() => handleIncreaseQuantity(med.id)} className="quantity-button">+</button>
              </div>
              <button 
                onClick={() => handleAddToCart(med)} 
                className="add-to-cart-button"
                >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </div>
        <button onClick={handleGoToCart} className="go-to-cart-button">
          Go to Cart Summary
        </button>
    </div>
  );
};

export default Inventory;
