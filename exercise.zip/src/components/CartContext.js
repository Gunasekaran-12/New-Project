import React, { createContext, useContext, useState } from 'react';

const CartContext = createContext();

export const useCart = () => {
  return useContext(CartContext);
};

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  const addToCart = (medicine) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === medicine.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === medicine.id
            ? { ...item, quantity: item.quantity + medicine.quantity }
            : item
        );
      } else {
        return [...prevCart, medicine];
      }
    });
  };

  const getTotalQuantity = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const getTotalAmount = () => {
    return cart.reduce((total, item) => total + item.quantity * item.rate, 0);
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, getTotalQuantity, getTotalAmount }}>
      {children}
    </CartContext.Provider>
  );
};
